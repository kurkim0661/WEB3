var express = require('express');
var app = express();

console.log(__dirname);
