var name = 'jihwan';
var letter = 'Dear ' + name +'i love playing baseball with my friend';
console.log(letter);
var letter = `Dear  ${name} i love playing baseball with my friend`;
console.log(letter);

