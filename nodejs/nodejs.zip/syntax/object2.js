function f1(a, b) {
	return console.log(a + b);
}

f1(1,2);

var c = f1;
c(2,3);
