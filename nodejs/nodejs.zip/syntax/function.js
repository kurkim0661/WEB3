console.log(1);
console.log(2);
console.log(3);
console.log('A');
console.log('B');
console.log('C');

function f123() {
	
}
