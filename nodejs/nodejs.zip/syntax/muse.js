var M = require('./mpart.js');
console.log(M);

M.f();
