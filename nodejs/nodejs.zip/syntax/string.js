console.log("1" + "jihwan");
var str = ' how can i help you? ';
var str2 = str.trim();
console.log(str2.length);
console.log(str.length);
