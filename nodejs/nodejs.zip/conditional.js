var args = process.argv;
console.log(args);
if(args[2] == true) {
	console.log('true');
} else {
	console.log('false');
}
